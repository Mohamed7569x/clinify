import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../app/config/app_theme.dart';
import '../../../data/models/patient_model.dart';
import '../../../widgets/shared_widgets.dart';
import '../controllers/patient_controllers.dart';
import '../../auth/controllers/auth_controller.dart';

class PatientProfileScreen extends GetView<PatientProfileController> {
  const PatientProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      body: Obx(() {
        final p = controller.profile.value;
        if (controller.isLoading.value || p == null) {
          return const Center(child: CircularProgressIndicator(color: AppTheme.primary));
        }
        return RefreshIndicator(
          color: AppTheme.primary,
          onRefresh: controller.loadProfile,
          child: CustomScrollView(
            slivers: [
              // Header
              SliverToBoxAdapter(
                child: Container(
                  color: AppTheme.white,
                  padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top + 12, bottom: 24),
                  child: Column(
                    children: [
                      // Top bar
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text('حسابي', style: TextStyle(fontFamily: 'Cairo', fontSize: 22, fontWeight: FontWeight.w800)),
                            GestureDetector(
                              onTap: () => _confirmLogout(context),
                              child: Container(
                                width: 38, height: 38,
                                decoration: BoxDecoration(color: AppTheme.errorSoft, borderRadius: BorderRadius.circular(10)),
                                child: const Icon(Icons.logout_rounded, color: AppTheme.error, size: 18),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 20),
                      UserAvatar(name: p.user.name, size: 72),
                      const SizedBox(height: 12),
                      Text(p.user.name, style: const TextStyle(fontFamily: 'Cairo', fontSize: 19, fontWeight: FontWeight.w700)),
                      const SizedBox(height: 2),
                      Text(p.user.email ?? p.user.phoneNumber ?? '', style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
                    ],
                  ),
                ),
              ),

              SliverPadding(
                padding: const EdgeInsets.all(20),
                sliver: SliverList(
                  delegate: SliverChildListDelegate([
                    _card('البيانات الشخصية', Icons.person_outline_rounded, [
                      _row('البريد', p.user.email ?? '—'),
                      _row('الهاتف', p.user.phoneNumber ?? '—'),
                      _row('الجنس', _genderAr(p.user.gender)),
                      _row('تاريخ الميلاد', p.user.dateOfBirth ?? '—'),
                    ]),
                    const SizedBox(height: 12),
                    _card('المعلومات الطبية', Icons.favorite_outline_rounded, [
                      _row('فصيلة الدم', p.profile.bloodType ?? '—'),
                      _row('الحساسية', p.profile.allergies ?? '—'),
                      _row('أمراض مزمنة', p.profile.chronicConditions ?? '—'),
                    ]),
                    const SizedBox(height: 12),
                    _card('جهة اتصال طوارئ', Icons.emergency_outlined, [
                      _row('الاسم', p.profile.emergencyContactName ?? '—'),
                      _row('الهاتف', p.profile.emergencyContactPhone ?? '—'),
                    ]),
                    const SizedBox(height: 20),
                    ElevatedButton.icon(
                      onPressed: () => Get.toNamed('/patient/edit-profile', arguments: p),
                      icon: const Icon(Icons.edit_outlined, size: 18),
                      label: const Text('تعديل الملف الشخصي'),
                    ),
                    const SizedBox(height: 12),
                    // Menu items
                    _menuItem(Icons.campaign_outlined, 'الإعلانات', () => Get.toNamed('/patient/announcements')),
                    _menuItem(Icons.notifications_outlined, 'الإشعارات', () => Get.toNamed('/patient/notifications')),
                  ]),
                ),
              ),
            ],
          ),
        );
      }),
    );
  }

  Widget _card(String title, IconData icon, List<Widget> rows) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: AppTheme.white, borderRadius: BorderRadius.circular(16),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 12, offset: const Offset(0, 2))]),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(width: 32, height: 32, decoration: BoxDecoration(color: AppTheme.primaryLight, borderRadius: BorderRadius.circular(8)),
              child: Icon(icon, size: 16, color: AppTheme.primary)),
          const SizedBox(width: 10),
          Text(title, style: const TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.w700, fontSize: 14)),
        ]),
        const SizedBox(height: 12),
        ...rows,
      ]),
    );
  }

  Widget _row(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text(label, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
        Flexible(child: Text(value, style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 13), textAlign: TextAlign.left)),
      ]),
    );
  }

  Widget _menuItem(IconData icon, String label, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(color: AppTheme.white, borderRadius: BorderRadius.circular(14),
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.02), blurRadius: 8, offset: const Offset(0, 2))]),
        child: Row(children: [
          Icon(icon, color: AppTheme.textSecondary, size: 20),
          const SizedBox(width: 12),
          Expanded(child: Text(label, style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 14))),
          const Icon(Icons.arrow_back_ios_rounded, color: AppTheme.textHint, size: 14),
        ]),
      ),
    );
  }

  void _confirmLogout(BuildContext ctx) {
    showModalBottomSheet(
      context: ctx, backgroundColor: AppTheme.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 56, height: 56, decoration: BoxDecoration(color: AppTheme.errorSoft, borderRadius: BorderRadius.circular(16)),
              child: const Icon(Icons.logout_rounded, color: AppTheme.error, size: 28)),
          const SizedBox(height: 16),
          const Text('تسجيل الخروج', style: TextStyle(fontFamily: 'Cairo', fontSize: 18, fontWeight: FontWeight.w700)),
          const SizedBox(height: 6),
          const Text('هل تريد تسجيل الخروج من حسابك؟', style: TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
          const SizedBox(height: 20),
          Row(children: [
            Expanded(child: OutlinedButton(onPressed: () => Get.back(), child: const Text('إلغاء'))),
            const SizedBox(width: 10),
            Expanded(child: ElevatedButton(
              onPressed: () { Get.back(); Get.find<AuthController>().logout(); },
              style: ElevatedButton.styleFrom(backgroundColor: AppTheme.error),
              child: const Text('خروج'),
            )),
          ]),
        ]),
      ),
    );
  }

  String _genderAr(String? g) {
    switch (g?.toUpperCase()) { case 'MALE': return 'ذكر'; case 'FEMALE': return 'أنثى'; default: return '—'; }
  }
}
