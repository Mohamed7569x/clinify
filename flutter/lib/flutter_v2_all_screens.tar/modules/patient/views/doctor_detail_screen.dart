import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../app/config/app_theme.dart';
import '../../../data/models/doctor_model.dart';
import '../../../widgets/shared_widgets.dart';
import '../controllers/patient_controllers.dart';

class DoctorDetailScreen extends StatelessWidget {
  const DoctorDetailScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final DoctorModel doctor = Get.arguments as DoctorModel;
    return Scaffold(
      backgroundColor: AppTheme.bg,
      appBar: AppBar(
        backgroundColor: AppTheme.white,
        title: const Text('الملف الشخصي'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_forward_rounded),
          onPressed: () => Get.back(),
        ),
      ),
      body: ListView(
        children: [
          // ── Header card ──
          Container(
            color: AppTheme.white,
            padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
            child: Column(
              children: [
                UserAvatar(name: doctor.user.name, size: 76),
                const SizedBox(height: 14),
                Text(doctor.user.name,
                    style: const TextStyle(fontFamily: 'Cairo', fontSize: 20, fontWeight: FontWeight.w800)),
                const SizedBox(height: 4),
                Text(doctor.specialty?.name ?? 'طب عام',
                    style: const TextStyle(color: AppTheme.textSecondary, fontSize: 14)),
                const SizedBox(height: 12),
                // Rating
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                      decoration: BoxDecoration(color: const Color(0xFFFFF7E6), borderRadius: BorderRadius.circular(8)),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.star_rounded, color: AppTheme.warning, size: 16),
                          const SizedBox(width: 4),
                          Text(doctor.profile.rating.toStringAsFixed(1),
                              style: const TextStyle(color: AppTheme.warning, fontWeight: FontWeight.w700, fontSize: 14)),
                        ],
                      ),
                    ),
                    const SizedBox(width: 10),
                    Text('(${doctor.profile.totalReviews} تقييم)',
                        style: const TextStyle(color: AppTheme.textHint, fontSize: 12)),
                  ],
                ),
                const SizedBox(height: 20),
                // Stats row
                Row(
                  children: [
                    _statItem(Icons.medical_services_outlined, 'التخصص', doctor.specialty?.name ?? 'عام'),
                    Container(width: 1, height: 40, color: AppTheme.border),
                    _statItem(Icons.badge_outlined, 'الترخيص', doctor.profile.licenseNumber ?? '—'),
                    Container(width: 1, height: 40, color: AppTheme.border),
                    _statItem(Icons.star_outline_rounded, 'التقييم', '${doctor.profile.rating.toStringAsFixed(1)}/5'),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),

          // ── Bio ──
          if (doctor.profile.bio != null && doctor.profile.bio!.isNotEmpty)
            _section('نبذة عن الطبيب', Icons.info_outline_rounded,
                child: Text(doctor.profile.bio!,
                    style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13.5, height: 1.7))),

          // ── Contact ──
          _section('معلومات التواصل', Icons.contact_phone_outlined,
              child: Column(
                children: [
                  if (doctor.user.email != null) _infoRow(Icons.email_outlined, 'البريد', doctor.user.email!),
                  if (doctor.user.phoneNumber != null) _infoRow(Icons.phone_outlined, 'الهاتف', doctor.user.phoneNumber!),
                  if (doctor.user.gender != null) _infoRow(Icons.person_outline, 'الجنس', _genderAr(doctor.user.gender!)),
                ],
              )),

          const SizedBox(height: 24),
          // ── Book button ──
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: ElevatedButton.icon(
              onPressed: () => Get.toNamed('/patient/booking', arguments: doctor),
              icon: const Icon(Icons.calendar_today_rounded, size: 18),
              label: const Text('حجز موعد'),
              style: ElevatedButton.styleFrom(
                elevation: 2,
                shadowColor: AppTheme.primary.withOpacity(0.3),
              ),
            ),
          ),
          const SizedBox(height: 32),
        ],
      ),
    );
  }

  Widget _statItem(IconData icon, String label, String value) {
    return Expanded(
      child: Column(
        children: [
          Icon(icon, color: AppTheme.primary, size: 20),
          const SizedBox(height: 6),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13), textAlign: TextAlign.center),
          const SizedBox(height: 2),
          Text(label, style: const TextStyle(color: AppTheme.textHint, fontSize: 11)),
        ],
      ),
    );
  }

  Widget _section(String title, IconData icon, {required Widget child}) {
    return Container(
      margin: const EdgeInsets.fromLTRB(20, 12, 20, 0),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppTheme.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 12, offset: const Offset(0, 2))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Icon(icon, size: 18, color: AppTheme.primary),
            const SizedBox(width: 8),
            Text(title, style: const TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.w700, fontSize: 14)),
          ]),
          const SizedBox(height: 12),
          child,
        ],
      ),
    );
  }

  Widget _infoRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        children: [
          Icon(icon, size: 16, color: AppTheme.textHint),
          const SizedBox(width: 10),
          Text('$label: ', style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
          Expanded(child: Text(value, style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 13), textAlign: TextAlign.left, textDirection: TextDirection.ltr)),
        ],
      ),
    );
  }

  String _genderAr(String g) {
    switch (g.toUpperCase()) {
      case 'MALE': return 'ذكر';
      case 'FEMALE': return 'أنثى';
      default: return 'آخر';
    }
  }
}

// ═══════════════════════════════════════════
// Booking Screen
// ═══════════════════════════════════════════

class BookingScreen extends StatefulWidget {
  const BookingScreen({super.key});
  @override
  State<BookingScreen> createState() => _BookingScreenState();
}

class _BookingScreenState extends State<BookingScreen> {
  late final BookingController ctrl;

  @override
  void initState() {
    super.initState();
    ctrl = Get.put(BookingController());
    ctrl.setDoctor(Get.arguments as DoctorModel);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      appBar: AppBar(
        backgroundColor: AppTheme.white,
        title: const Text('حجز موعد'),
        leading: IconButton(icon: const Icon(Icons.arrow_forward_rounded), onPressed: () => Get.back()),
      ),
      body: ListView(
        children: [
          // Doctor mini card
          Container(
            color: AppTheme.white,
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
            child: Row(
              children: [
                UserAvatar(name: ctrl.doctor.user.name, size: 44),
                const SizedBox(width: 12),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(ctrl.doctor.user.name, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                    Text(ctrl.doctor.specialty?.name ?? 'طب عام', style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),

          // Date picker
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 20),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color: AppTheme.white, borderRadius: BorderRadius.circular(16),
                boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 12, offset: const Offset(0, 2))]),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(children: [
                  Icon(Icons.calendar_month_rounded, color: AppTheme.primary, size: 18),
                  SizedBox(width: 8),
                  Text('اختر التاريخ', style: TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.w700, fontSize: 15)),
                ]),
                const SizedBox(height: 8),
                Theme(
                  data: Theme.of(context).copyWith(
                    colorScheme: Theme.of(context).colorScheme.copyWith(primary: AppTheme.primary, onPrimary: Colors.white),
                  ),
                  child: CalendarDatePicker(
                    initialDate: DateTime.now().add(const Duration(days: 1)),
                    firstDate: DateTime.now(),
                    lastDate: DateTime.now().add(const Duration(days: 60)),
                    onDateChanged: ctrl.selectDate,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),

          // Slots
          Obx(() {
            if (ctrl.selectedDate.value == null) {
              return _infoBox('اختر تاريخاً لعرض المواعيد المتاحة', Icons.touch_app_rounded);
            }
            if (ctrl.isLoadingSlots.value) {
              return const Padding(padding: EdgeInsets.all(30), child: Center(child: CircularProgressIndicator(color: AppTheme.primary)));
            }
            if (ctrl.availableSlots.isEmpty) {
              return _infoBox('لا توجد مواعيد متاحة في هذا اليوم', Icons.event_busy_rounded);
            }
            return Container(
              margin: const EdgeInsets.symmetric(horizontal: 20),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: AppTheme.white, borderRadius: BorderRadius.circular(16),
                  boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 12, offset: const Offset(0, 2))]),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    const Icon(Icons.schedule_rounded, color: AppTheme.primary, size: 18),
                    const SizedBox(width: 8),
                    const Text('المواعيد المتاحة', style: TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.w700, fontSize: 15)),
                    const Spacer(),
                    Text('${ctrl.availableSlots.length} موعد', style: const TextStyle(color: AppTheme.textHint, fontSize: 12)),
                  ]),
                  const SizedBox(height: 14),
                  Wrap(
                    spacing: 10,
                    runSpacing: 10,
                    children: ctrl.availableSlots.map((slot) {
                      final selected = ctrl.selectedSlot.value == slot;
                      return GestureDetector(
                        onTap: () => ctrl.selectSlot(slot),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 180),
                          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 11),
                          decoration: BoxDecoration(
                            color: selected ? AppTheme.primary : AppTheme.inputBg,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: selected ? AppTheme.primary : AppTheme.border),
                            boxShadow: selected ? [BoxShadow(color: AppTheme.primary.withOpacity(0.2), blurRadius: 8, offset: const Offset(0, 2))] : null,
                          ),
                          child: Text(
                            slot.startTime.substring(0, 5),
                            textDirection: TextDirection.ltr,
                            style: TextStyle(color: selected ? Colors.white : AppTheme.textPrimary, fontWeight: FontWeight.w600, fontSize: 14),
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ],
              ),
            );
          }),
          const SizedBox(height: 28),

          // Confirm
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Obx(() => ElevatedButton(
                  onPressed: ctrl.selectedSlot.value == null || ctrl.isBooking.value
                      ? null
                      : () async {
                          final ok = await ctrl.confirmBooking();
                          if (ok) {
                            Get.back();
                            Get.back();
                            Get.snackbar('تم الحجز!', 'تم حجز موعدك بنجاح',
                                snackPosition: SnackPosition.BOTTOM,
                                backgroundColor: AppTheme.successSoft,
                                colorText: AppTheme.success);
                          }
                        },
                  child: ctrl.isBooking.value
                      ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white))
                      : const Text('تأكيد الحجز'),
                )),
          ),
          const SizedBox(height: 32),
        ],
      ),
    );
  }

  Widget _infoBox(String text, IconData icon) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(color: AppTheme.white, borderRadius: BorderRadius.circular(16)),
      child: Column(
        children: [
          Container(
            width: 52, height: 52,
            decoration: BoxDecoration(color: AppTheme.primaryLight, borderRadius: BorderRadius.circular(14)),
            child: Icon(icon, color: AppTheme.primary, size: 24),
          ),
          const SizedBox(height: 12),
          Text(text, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13), textAlign: TextAlign.center),
        ],
      ),
    );
  }
}
