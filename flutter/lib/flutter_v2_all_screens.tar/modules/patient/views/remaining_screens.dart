import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../app/config/app_theme.dart';
import '../../../data/models/patient_model.dart';
import '../../../data/models/other_models.dart';
import '../../../data/repositories/all_repositories.dart';
import '../../../widgets/shared_widgets.dart';
import '../controllers/patient_controllers.dart';

// ═══════════════════════════════════════════
// Edit Profile
// ═══════════════════════════════════════════

class EditProfileScreen extends StatefulWidget {
  const EditProfileScreen({super.key});
  @override
  State<EditProfileScreen> createState() => _EditProfileState();
}

class _EditProfileState extends State<EditProfileScreen> {
  final _fk = GlobalKey<FormState>();
  late final PatientModel _p;
  late final TextEditingController _name, _email, _phone, _blood, _allergy, _chronic, _ecName, _ecPhone;

  @override
  void initState() {
    super.initState();
    _p = Get.arguments as PatientModel;
    _name = TextEditingController(text: _p.user.name);
    _email = TextEditingController(text: _p.user.email ?? '');
    _phone = TextEditingController(text: _p.user.phoneNumber ?? '');
    _blood = TextEditingController(text: _p.profile.bloodType ?? '');
    _allergy = TextEditingController(text: _p.profile.allergies ?? '');
    _chronic = TextEditingController(text: _p.profile.chronicConditions ?? '');
    _ecName = TextEditingController(text: _p.profile.emergencyContactName ?? '');
    _ecPhone = TextEditingController(text: _p.profile.emergencyContactPhone ?? '');
  }

  @override
  void dispose() { for (final c in [_name,_email,_phone,_blood,_allergy,_chronic,_ecName,_ecPhone]) c.dispose(); super.dispose(); }

  Future<void> _save() async {
    if (!_fk.currentState!.validate()) return;
    final d = <String, dynamic>{};
    void _c(String k, TextEditingController c, String? old) { if (c.text.trim() != (old ?? '')) d[k] = c.text.trim().isNotEmpty ? c.text.trim() : null; }
    _c('name', _name, _p.user.name); _c('email', _email, _p.user.email); _c('phone_number', _phone, _p.user.phoneNumber);
    _c('blood_type', _blood, _p.profile.bloodType); _c('allergies', _allergy, _p.profile.allergies);
    _c('chronic_conditions', _chronic, _p.profile.chronicConditions);
    _c('emergency_contact_name', _ecName, _p.profile.emergencyContactName);
    _c('emergency_contact_phone', _ecPhone, _p.profile.emergencyContactPhone);
    if (d.isEmpty) { Get.back(); return; }
    await Get.find<PatientProfileController>().updateProfile(d);
    Get.back();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      appBar: AppBar(backgroundColor: AppTheme.white, title: const Text('تعديل الملف'),
          leading: IconButton(icon: const Icon(Icons.arrow_forward_rounded), onPressed: () => Get.back())),
      body: Form(
        key: _fk,
        child: ListView(padding: const EdgeInsets.all(20), children: [
          _sec('البيانات الشخصية', Icons.person_outline_rounded),
          const SizedBox(height: 14),
          _f('الاسم الكامل', _name, req: true), _f('البريد الإلكتروني', _email, kb: TextInputType.emailAddress, ltr: true),
          _f('رقم الهاتف', _phone, kb: TextInputType.phone, ltr: true),
          const SizedBox(height: 20),
          _sec('المعلومات الطبية', Icons.favorite_outline_rounded),
          const SizedBox(height: 14),
          _f('فصيلة الدم', _blood, hint: 'مثال: A+'), _f('الحساسية', _allergy, hint: 'مثال: بنسلين', ml: 2),
          _f('أمراض مزمنة', _chronic, hint: 'مثال: سكري', ml: 2),
          const SizedBox(height: 20),
          _sec('جهة اتصال طوارئ', Icons.emergency_outlined),
          const SizedBox(height: 14),
          _f('اسم جهة الاتصال', _ecName), _f('هاتف الطوارئ', _ecPhone, kb: TextInputType.phone, ltr: true),
          const SizedBox(height: 28),
          Obx(() => ElevatedButton(
            onPressed: Get.find<PatientProfileController>().isSaving.value ? null : _save,
            child: Get.find<PatientProfileController>().isSaving.value
                ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white))
                : const Text('حفظ التغييرات'),
          )),
          const SizedBox(height: 20),
        ]),
      ),
    );
  }

  Widget _sec(String t, IconData i) => Row(children: [
    Container(width: 32, height: 32, decoration: BoxDecoration(color: AppTheme.primaryLight, borderRadius: BorderRadius.circular(8)),
        child: Icon(i, size: 16, color: AppTheme.primary)),
    const SizedBox(width: 10),
    Text(t, style: const TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.w700, fontSize: 15, color: AppTheme.primary)),
  ]);

  Widget _f(String l, TextEditingController c, {bool req = false, TextInputType? kb, String? hint, int ml = 1, bool ltr = false}) {
    return Padding(padding: const EdgeInsets.only(bottom: 14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(l, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12.5, fontWeight: FontWeight.w500)),
      const SizedBox(height: 6),
      TextFormField(controller: c, keyboardType: kb, maxLines: ml, textDirection: ltr ? TextDirection.ltr : null,
          decoration: InputDecoration(hintText: hint),
          validator: req ? (v) => v == null || v.trim().isEmpty ? '$l مطلوب' : null : null),
    ]));
  }
}

// ═══════════════════════════════════════════
// Patient Chat Screen
// ═══════════════════════════════════════════

class PatientChatScreen extends StatefulWidget {
  const PatientChatScreen({super.key});
  @override
  State<PatientChatScreen> createState() => _ChatState();
}

class _ChatState extends State<PatientChatScreen> {
  late final PatientChatController ctrl;
  final _sc = ScrollController();

  @override
  void initState() { super.initState(); ctrl = Get.put(PatientChatController()); ctrl.setAppointmentId(Get.arguments as String); }
  void _scroll() { WidgetsBinding.instance.addPostFrameCallback((_) { if (_sc.hasClients) _sc.animateTo(_sc.position.maxScrollExtent, duration: const Duration(milliseconds: 200), curve: Curves.easeOut); }); }
  @override
  void dispose() { _sc.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      appBar: AppBar(backgroundColor: AppTheme.white, title: const Text('المحادثة'),
          leading: IconButton(icon: const Icon(Icons.arrow_forward_rounded), onPressed: () => Get.back()),
          actions: [IconButton(icon: const Icon(Icons.refresh_rounded), onPressed: ctrl.loadMessages)]),
      body: Column(children: [
        Expanded(child: Obx(() {
          if (ctrl.isLoading.value && ctrl.messages.isEmpty) return const Center(child: CircularProgressIndicator(color: AppTheme.primary));
          if (ctrl.messages.isEmpty) return const EmptyState(icon: Icons.chat_bubble_outline_rounded, title: 'لا توجد رسائل', subtitle: 'ابدأ محادثة مع طبيبك');
          _scroll();
          return ListView.builder(
            controller: _sc, padding: const EdgeInsets.all(16), itemCount: ctrl.messages.length,
            itemBuilder: (_, i) {
              final m = ctrl.messages[i]; final me = m.senderRole == 'PATIENT';
              return Align(alignment: me ? Alignment.centerLeft : Alignment.centerRight,
                child: Container(
                  constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  decoration: BoxDecoration(
                    color: me ? AppTheme.primary : AppTheme.white,
                    borderRadius: BorderRadius.only(
                      topLeft: const Radius.circular(14), topRight: const Radius.circular(14),
                      bottomLeft: Radius.circular(me ? 4 : 14), bottomRight: Radius.circular(me ? 14 : 4)),
                    boxShadow: me ? null : [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8, offset: const Offset(0, 2))],
                  ),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    if (!me) const Padding(padding: EdgeInsets.only(bottom: 4), child: Text('الطبيب', style: TextStyle(color: AppTheme.primary, fontSize: 11, fontWeight: FontWeight.w700))),
                    Text(m.message, style: TextStyle(color: me ? Colors.white : AppTheme.textPrimary, fontSize: 14, height: 1.4)),
                    const SizedBox(height: 4),
                    Text(_ft(m.createdAt), style: TextStyle(color: me ? Colors.white60 : AppTheme.textHint, fontSize: 10)),
                  ]),
                ),
              );
            },
          );
        })),
        // Input
        Container(
          padding: const EdgeInsets.fromLTRB(16, 10, 8, 10),
          decoration: BoxDecoration(color: AppTheme.white, boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8, offset: const Offset(0, -2))]),
          child: SafeArea(top: false, child: Row(children: [
            Expanded(child: TextField(controller: ctrl.messageCtrl,
                decoration: InputDecoration(hintText: 'اكتب رسالة...', filled: true, fillColor: AppTheme.inputBg,
                    contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none)),
                textInputAction: TextInputAction.send, onSubmitted: (_) => ctrl.sendMessage())),
            const SizedBox(width: 6),
            Obx(() => GestureDetector(
              onTap: ctrl.isSending.value ? null : ctrl.sendMessage,
              child: Container(width: 42, height: 42, decoration: BoxDecoration(color: AppTheme.primary, borderRadius: BorderRadius.circular(12)),
                  child: ctrl.isSending.value
                      ? const Padding(padding: EdgeInsets.all(10), child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                      : const Icon(Icons.send_rounded, color: Colors.white, size: 20)),
            )),
          ])),
        ),
      ]),
    );
  }
  String _ft(String dt) { try { final d = DateTime.parse(dt); return '${d.hour.toString().padLeft(2,'0')}:${d.minute.toString().padLeft(2,'0')}'; } catch (_) { return ''; } }
}

// ═══════════════════════════════════════════
// Prescriptions Screen
// ═══════════════════════════════════════════

class PrescriptionsScreen extends StatefulWidget {
  const PrescriptionsScreen({super.key});
  @override
  State<PrescriptionsScreen> createState() => _RxState();
}

class _RxState extends State<PrescriptionsScreen> {
  final PrescriptionRepository _repo = PrescriptionRepository();
  List<PrescriptionModel> _rx = []; bool _ld = true;

  @override
  void initState() { super.initState(); _load(); }
  Future<void> _load() async { setState(() => _ld = true); try { _rx = await _repo.listForAppointment(Get.arguments as String); } catch (_) {} setState(() => _ld = false); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      appBar: AppBar(backgroundColor: AppTheme.white, title: const Text('الوصفات الطبية'),
          leading: IconButton(icon: const Icon(Icons.arrow_forward_rounded), onPressed: () => Get.back())),
      body: _ld ? const Center(child: CircularProgressIndicator(color: AppTheme.primary))
          : _rx.isEmpty ? const EmptyState(icon: Icons.medication_outlined, title: 'لا توجد وصفات', subtitle: 'لم يضف الطبيب وصفات بعد')
          : RefreshIndicator(color: AppTheme.primary, onRefresh: _load, child: ListView.builder(
              padding: const EdgeInsets.all(20), itemCount: _rx.length,
              itemBuilder: (_, i) {
                final r = _rx[i];
                return Container(
                  margin: const EdgeInsets.only(bottom: 12), padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(color: AppTheme.white, borderRadius: BorderRadius.circular(16),
                      boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 12, offset: const Offset(0, 2))]),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      Container(width: 42, height: 42, decoration: BoxDecoration(color: AppTheme.successSoft, borderRadius: BorderRadius.circular(11)),
                          child: const Icon(Icons.medication_rounded, color: AppTheme.success, size: 22)),
                      const SizedBox(width: 12),
                      Expanded(child: Text(r.medication, style: const TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.w700, fontSize: 15))),
                    ]),
                    const SizedBox(height: 14),
                    if (r.dosage != null) _rxRow(Icons.scale_outlined, 'الجرعة', r.dosage!),
                    if (r.frequency != null) _rxRow(Icons.schedule_outlined, 'التكرار', r.frequency!),
                    if (r.duration != null) _rxRow(Icons.calendar_today_outlined, 'المدة', r.duration!),
                    if (r.notes != null && r.notes!.isNotEmpty) ...[
                      const SizedBox(height: 8),
                      Container(width: double.infinity, padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(color: AppTheme.inputBg, borderRadius: BorderRadius.circular(8)),
                          child: Text(r.notes!, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12, height: 1.5))),
                    ],
                  ]),
                );
              })),
    );
  }

  Widget _rxRow(IconData i, String l, String v) => Padding(padding: const EdgeInsets.only(bottom: 6), child: Row(children: [
    Icon(i, size: 15, color: AppTheme.textHint), const SizedBox(width: 8),
    Text('$l: ', style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
    Text(v, style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 13)),
  ]));
}

// ═══════════════════════════════════════════
// Review Screen
// ═══════════════════════════════════════════

class ReviewScreen extends StatefulWidget {
  const ReviewScreen({super.key});
  @override
  State<ReviewScreen> createState() => _ReviewState();
}

class _ReviewState extends State<ReviewScreen> {
  final ReviewRepository _repo = ReviewRepository();
  final _cc = TextEditingController();
  int _r = 0; bool _sub = false; bool _done = false; bool _chk = true;
  late final String _aid;

  @override
  void initState() { super.initState(); _aid = Get.arguments as String; _check(); }
  Future<void> _check() async { final e = await _repo.getForAppointment(_aid); if (e != null) setState(() { _done = true; _r = e.rating; }); setState(() => _chk = false); }

  Future<void> _submit() async {
    if (_r == 0) { Get.snackbar('خطأ', 'يرجى اختيار تقييم', snackPosition: SnackPosition.BOTTOM, backgroundColor: AppTheme.errorSoft, colorText: AppTheme.error); return; }
    setState(() => _sub = true);
    try { await _repo.create(appointmentId: _aid, rating: _r, comment: _cc.text.trim().isNotEmpty ? _cc.text.trim() : null);
      Get.back(); Get.snackbar('شكراً!', 'تم إرسال تقييمك', snackPosition: SnackPosition.BOTTOM, backgroundColor: AppTheme.successSoft, colorText: AppTheme.success);
    } catch (_) {} setState(() => _sub = false);
  }

  @override
  void dispose() { _cc.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.white,
      appBar: AppBar(backgroundColor: AppTheme.white, title: const Text('التقييم'),
          leading: IconButton(icon: const Icon(Icons.arrow_forward_rounded), onPressed: () => Get.back())),
      body: _chk ? const Center(child: CircularProgressIndicator(color: AppTheme.primary))
          : _done ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
              Container(width: 64, height: 64, decoration: BoxDecoration(color: AppTheme.successSoft, borderRadius: BorderRadius.circular(18)),
                  child: const Icon(Icons.check_circle_rounded, color: AppTheme.success, size: 32)),
              const SizedBox(height: 16),
              const Text('تم التقييم مسبقاً', style: TextStyle(fontFamily: 'Cairo', fontSize: 18, fontWeight: FontWeight.w700)),
              const SizedBox(height: 10),
              InteractiveStarRating(rating: _r, onChanged: (_) {}, size: 32),
              const SizedBox(height: 24),
              OutlinedButton(onPressed: () => Get.back(), child: const Text('رجوع')),
            ]))
          : Padding(padding: const EdgeInsets.all(24), child: Column(children: [
              const SizedBox(height: 20),
              const Text('كيف كانت تجربتك؟', style: TextStyle(fontFamily: 'Cairo', fontSize: 22, fontWeight: FontWeight.w800)),
              const SizedBox(height: 6),
              const Text('تقييمك يساعد في تحسين جودة الخدمة', style: TextStyle(color: AppTheme.textSecondary, fontSize: 14)),
              const SizedBox(height: 32),
              InteractiveStarRating(rating: _r, onChanged: (v) => setState(() => _r = v), size: 44),
              const SizedBox(height: 8),
              Text(_rl(_r), style: const TextStyle(color: AppTheme.warning, fontWeight: FontWeight.w600, fontSize: 14)),
              const SizedBox(height: 28),
              TextField(controller: _cc, maxLines: 4, decoration: const InputDecoration(hintText: 'اكتب تعليقاً (اختياري)...')),
              const Spacer(),
              ElevatedButton(onPressed: _sub ? null : _submit,
                  child: _sub ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white)) : const Text('إرسال التقييم')),
            ])),
    );
  }
  String _rl(int r) { switch (r) { case 1: return 'سيء'; case 2: return 'أقل من المتوسط'; case 3: return 'متوسط'; case 4: return 'جيد'; case 5: return 'ممتاز'; default: return 'اضغط للتقييم'; } }
}
