import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../app/config/app_theme.dart';
import '../../../widgets/shared_widgets.dart';
import '../controllers/patient_controllers.dart';

class PatientAppointmentsScreen extends GetView<PatientAppointmentsController> {
  const PatientAppointmentsScreen({super.key});

  static const _tabs = ['', 'PENDING', 'CONFIRMED', 'COMPLETED', 'CANCELLED'];
  static const _labels = ['الكل', 'بانتظار', 'مؤكد', 'مكتمل', 'ملغي'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      body: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: Container(
              color: AppTheme.white,
              padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top + 12, left: 20, right: 20, bottom: 12),
              child: const Text('المواعيد', style: TextStyle(fontFamily: 'Cairo', fontSize: 22, fontWeight: FontWeight.w800)),
            ),
          ),
          // Tabs
          SliverToBoxAdapter(
            child: Container(
              color: AppTheme.white,
              height: 44,
              child: Obx(() => ListView.builder(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    itemCount: _tabs.length,
                    itemBuilder: (_, i) {
                      final sel = controller.statusFilter.value == _tabs[i];
                      return GestureDetector(
                        onTap: () => controller.setFilter(_tabs[i]),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 180),
                          margin: const EdgeInsets.only(left: 8, bottom: 8),
                          padding: const EdgeInsets.symmetric(horizontal: 18),
                          decoration: BoxDecoration(
                            color: sel ? AppTheme.primary : AppTheme.inputBg,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          alignment: Alignment.center,
                          child: Text(_labels[i], style: TextStyle(color: sel ? Colors.white : AppTheme.textSecondary, fontSize: 13, fontWeight: FontWeight.w600)),
                        ),
                      );
                    },
                  )),
            ),
          ),
          // List
          Obx(() {
            if (controller.isLoading.value) {
              return const SliverFillRemaining(child: Center(child: CircularProgressIndicator(color: AppTheme.primary)));
            }
            if (controller.appointments.isEmpty) {
              return const SliverFillRemaining(
                child: EmptyState(icon: Icons.calendar_today_outlined, title: 'لا توجد مواعيد', subtitle: 'احجز موعدك الأول من صفحة الأطباء'),
              );
            }
            return SliverPadding(
              padding: const EdgeInsets.all(20),
              sliver: SliverList(
                delegate: SliverChildBuilderDelegate((ctx, i) {
                  final a = controller.appointments[i];
                  return Container(
                    margin: const EdgeInsets.only(bottom: 12),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: AppTheme.white,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 12, offset: const Offset(0, 2))],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(children: [
                              Container(
                                width: 42, height: 42,
                                decoration: BoxDecoration(color: AppTheme.primaryLight, borderRadius: BorderRadius.circular(11)),
                                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                                  Text(a.date.split('-').last, style: const TextStyle(fontFamily: 'Cairo', fontSize: 15, fontWeight: FontWeight.w800, color: AppTheme.primary, height: 1)),
                                  Text(_monthAr(a.date), style: const TextStyle(fontSize: 9, color: AppTheme.primary, fontWeight: FontWeight.w600)),
                                ]),
                              ),
                              const SizedBox(width: 12),
                              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Text('${a.startTime.substring(0, 5)} - ${a.endTime.substring(0, 5)}', style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14), textDirection: TextDirection.ltr),
                                const SizedBox(height: 2),
                                Text('الطبيب: ${a.doctorId.substring(0, 8)}...', style: const TextStyle(color: AppTheme.textSecondary, fontSize: 11.5)),
                              ]),
                            ]),
                            StatusBadge(a.status),
                          ],
                        ),
                        if (a.consultationNotes != null) ...[
                          const SizedBox(height: 10),
                          Container(
                            width: double.infinity, padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(color: AppTheme.inputBg, borderRadius: BorderRadius.circular(8)),
                            child: Text(a.consultationNotes!, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12, height: 1.4), maxLines: 2, overflow: TextOverflow.ellipsis),
                          ),
                        ],
                        const SizedBox(height: 12),
                        // Actions
                        Row(
                          children: [
                            if (a.isUpcoming)
                              _actionBtn('إلغاء', Icons.close_rounded, AppTheme.error, AppTheme.errorSoft, () => _showCancel(context, a.id)),
                            if (a.isUpcoming) const SizedBox(width: 8),
                            if (a.isConfirmed || a.isCompleted)
                              _actionBtn('محادثة', Icons.chat_bubble_outline_rounded, AppTheme.primary, AppTheme.primaryLight, () => Get.toNamed('/patient/chat', arguments: a.id)),
                            if (a.isCompleted) ...[
                              const SizedBox(width: 8),
                              _actionBtn('الوصفات', Icons.medication_outlined, AppTheme.purple, AppTheme.purpleSoft, () => Get.toNamed('/patient/prescriptions', arguments: a.id)),
                              const SizedBox(width: 8),
                              _actionBtn('تقييم', Icons.star_outline_rounded, AppTheme.warning, AppTheme.warningSoft, () => Get.toNamed('/patient/review', arguments: a.id)),
                            ],
                          ],
                        ),
                      ],
                    ),
                  );
                }, childCount: controller.appointments.length),
              ),
            );
          }),
        ],
      ),
    );
  }

  Widget _actionBtn(String label, IconData icon, Color color, Color bg, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
        decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(8)),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: 14, color: color),
          const SizedBox(width: 5),
          Text(label, style: TextStyle(color: color, fontSize: 11.5, fontWeight: FontWeight.w600)),
        ]),
      ),
    );
  }

  void _showCancel(BuildContext ctx, String id) {
    final rc = TextEditingController();
    showModalBottomSheet(
      context: ctx,
      backgroundColor: AppTheme.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => Padding(
        padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(ctx).viewInsets.bottom + 20),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('إلغاء الموعد', style: TextStyle(fontFamily: 'Cairo', fontSize: 18, fontWeight: FontWeight.w700)),
          const SizedBox(height: 4),
          const Text('هل أنت متأكد من إلغاء هذا الموعد؟', style: TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
          const SizedBox(height: 16),
          TextField(controller: rc, maxLines: 2, decoration: const InputDecoration(hintText: 'السبب (اختياري)')),
          const SizedBox(height: 16),
          Row(children: [
            Expanded(child: OutlinedButton(onPressed: () => Get.back(), child: const Text('تراجع'))),
            const SizedBox(width: 10),
            Expanded(
              child: ElevatedButton(
                onPressed: () { Get.back(); controller.cancelAppointment(id, reason: rc.text.trim().isNotEmpty ? rc.text.trim() : null); },
                style: ElevatedButton.styleFrom(backgroundColor: AppTheme.error),
                child: const Text('إلغاء الموعد'),
              ),
            ),
          ]),
        ]),
      ),
    );
  }

  String _monthAr(String d) {
    const m = ['يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'];
    try { return m[int.parse(d.split('-')[1]) - 1]; } catch (_) { return ''; }
  }
}
