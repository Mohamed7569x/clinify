import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../app/config/app_theme.dart';
import '../../../widgets/shared_widgets.dart';
import '../../shared/controllers/notification_controller.dart';
import '../controllers/doctor_controllers.dart';

class DoctorHomeScreen extends GetView<DoctorHomeController> {
  const DoctorHomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      body: Obx(() {
        if (controller.isLoading.value) return const Center(child: CircularProgressIndicator(color: AppTheme.primary));
        return RefreshIndicator(
          color: AppTheme.primary,
          onRefresh: controller.loadData,
          child: CustomScrollView(slivers: [
            // Header
            SliverToBoxAdapter(child: Container(
              color: AppTheme.white,
              padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top + 12, left: 20, right: 20, bottom: 16),
              child: Row(children: [
                Container(width: 42, height: 42, decoration: BoxDecoration(color: AppTheme.primaryLight, borderRadius: BorderRadius.circular(12)),
                    child: const Icon(Icons.person_rounded, color: AppTheme.primary, size: 22)),
                const SizedBox(width: 12),
                const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('مرحباً دكتور 👋', style: TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
                  Text('لوحة التحكم', style: TextStyle(fontFamily: 'Cairo', fontSize: 20, fontWeight: FontWeight.w800)),
                ])),
                Obx(() {
                  final n = Get.find<NotificationController>();
                  return GestureDetector(
                    onTap: () => Get.toNamed('/doctor/notifications'),
                    child: Container(width: 42, height: 42, decoration: BoxDecoration(color: AppTheme.inputBg, borderRadius: BorderRadius.circular(12)),
                        child: Stack(alignment: Alignment.center, children: [
                          const Icon(Icons.notifications_outlined, color: AppTheme.textSecondary, size: 22),
                          if (n.unreadCount.value > 0) Positioned(top: 8, right: 8, child: Container(width: 8, height: 8, decoration: const BoxDecoration(color: AppTheme.error, shape: BoxShape.circle))),
                        ])),
                  );
                }),
              ]),
            )),

            // Stats
            SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.fromLTRB(20, 16, 20, 0), child: Row(children: [
              _stat('مواعيد اليوم', '${controller.todayAppointments.length}', Icons.calendar_today_rounded, AppTheme.primary, AppTheme.primaryLight),
              const SizedBox(width: 12),
              _stat('بانتظار التأكيد', '${controller.pendingCount.value}', Icons.hourglass_top_rounded, AppTheme.warning, AppTheme.warningSoft),
            ]))),

            // Quick actions
            SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.fromLTRB(20, 20, 20, 0), child: Row(children: [
              _action('الإعلانات', Icons.campaign_rounded, AppTheme.warning, const Color(0xFFFFF7E6), () => Get.toNamed('/doctor/announcements')),
              const SizedBox(width: 12),
              _action('الإشعارات', Icons.notifications_outlined, AppTheme.info, const Color(0xFFEBF2FF), () => Get.toNamed('/doctor/notifications')),
            ]))),

            // Today's appointments
            SliverToBoxAdapter(child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 24, 20, 12),
              child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                const Text('مواعيد اليوم', style: TextStyle(fontFamily: 'Cairo', fontSize: 17, fontWeight: FontWeight.w700)),
                if (controller.todayAppointments.isNotEmpty) Text('${controller.todayAppointments.length} موعد', style: const TextStyle(color: AppTheme.textHint, fontSize: 12)),
              ]),
            )),

            if (controller.todayAppointments.isEmpty)
              const SliverToBoxAdapter(child: Padding(padding: EdgeInsets.symmetric(horizontal: 20),
                  child: _EmptyBox(icon: Icons.event_available_rounded, title: 'لا توجد مواعيد اليوم', sub: 'استمتع بوقتك!')))
            else
              SliverPadding(padding: const EdgeInsets.symmetric(horizontal: 20), sliver: SliverList(
                delegate: SliverChildBuilderDelegate((_, i) {
                  final a = controller.todayAppointments[i];
                  return Container(
                    margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(color: AppTheme.white, borderRadius: BorderRadius.circular(14),
                        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 12, offset: const Offset(0, 2))]),
                    child: Row(children: [
                      Container(width: 46, height: 46, decoration: BoxDecoration(color: AppTheme.primaryLight, borderRadius: BorderRadius.circular(12)),
                          child: Center(child: Text(a.startTime.substring(0, 5), textDirection: TextDirection.ltr,
                              style: const TextStyle(color: AppTheme.primary, fontWeight: FontWeight.w700, fontSize: 13)))),
                      const SizedBox(width: 14),
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('مريض: ${a.patientId.substring(0, 8)}...', style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13.5)),
                        const SizedBox(height: 2),
                        Text('${a.startTime.substring(0, 5)} – ${a.endTime.substring(0, 5)}', textDirection: TextDirection.ltr, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
                      ])),
                      StatusBadge(a.status),
                    ]),
                  );
                }, childCount: controller.todayAppointments.length),
              )),
            const SliverToBoxAdapter(child: SizedBox(height: 32)),
          ]),
        );
      }),
    );
  }

  Widget _stat(String l, String v, IconData i, Color c, Color bg) => Expanded(child: Container(
    padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: AppTheme.white, borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 12, offset: const Offset(0, 2))]),
    child: Row(children: [
      Container(width: 44, height: 44, decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(12)), child: Icon(i, color: c, size: 22)),
      const SizedBox(width: 12),
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(v, style: const TextStyle(fontFamily: 'Cairo', fontSize: 22, fontWeight: FontWeight.w800)),
        Text(l, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 11)),
      ]),
    ]),
  ));

  Widget _action(String l, IconData i, Color c, Color bg, VoidCallback fn) => Expanded(child: GestureDetector(onTap: fn, child: Container(
    padding: const EdgeInsets.symmetric(vertical: 16), decoration: BoxDecoration(color: AppTheme.white, borderRadius: BorderRadius.circular(14),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.02), blurRadius: 8, offset: const Offset(0, 2))]),
    child: Column(children: [
      Container(width: 44, height: 44, decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(12)), child: Icon(i, color: c, size: 22)),
      const SizedBox(height: 8),
      Text(l, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppTheme.textSecondary)),
    ]),
  )));
}

class _EmptyBox extends StatelessWidget {
  final IconData icon; final String title; final String sub;
  const _EmptyBox({required this.icon, required this.title, required this.sub});
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.symmetric(vertical: 36), decoration: BoxDecoration(color: AppTheme.white, borderRadius: BorderRadius.circular(14)),
      child: Column(children: [
        Container(width: 52, height: 52, decoration: BoxDecoration(color: AppTheme.primaryLight, borderRadius: BorderRadius.circular(14)), child: Icon(icon, color: AppTheme.primary, size: 26)),
        const SizedBox(height: 12),
        Text(title, style: const TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.w700, fontSize: 14)),
        const SizedBox(height: 4),
        Text(sub, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
      ]));
}
