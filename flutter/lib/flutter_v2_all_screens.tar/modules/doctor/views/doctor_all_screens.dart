import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../app/config/app_theme.dart';
import '../../../widgets/shared_widgets.dart';
import '../../../data/providers/storage_provider.dart';
import '../../auth/controllers/auth_controller.dart';
import '../controllers/doctor_controllers.dart';

// ═══════════════════════════════════════════
// Doctor Appointments
// ═══════════════════════════════════════════

class DoctorAppointmentsScreen extends GetView<DoctorAppointmentsController> {
  const DoctorAppointmentsScreen({super.key});
  static const _tabs = ['', 'PENDING', 'CONFIRMED', 'COMPLETED', 'CANCELLED'];
  static const _labels = ['الكل', 'بانتظار', 'مؤكد', 'مكتمل', 'ملغي'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      body: CustomScrollView(slivers: [
        SliverToBoxAdapter(child: Container(color: AppTheme.white,
            padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top + 12, left: 20, right: 20, bottom: 12),
            child: const Text('المواعيد', style: TextStyle(fontFamily: 'Cairo', fontSize: 22, fontWeight: FontWeight.w800)))),
        SliverToBoxAdapter(child: Container(color: AppTheme.white, height: 44, child: Obx(() => ListView.builder(
          scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 20), itemCount: _tabs.length,
          itemBuilder: (_, i) { final s = controller.statusFilter.value == _tabs[i];
            return GestureDetector(onTap: () => controller.setFilter(_tabs[i]), child: AnimatedContainer(
              duration: const Duration(milliseconds: 180), margin: const EdgeInsets.only(left: 8, bottom: 8),
              padding: const EdgeInsets.symmetric(horizontal: 18),
              decoration: BoxDecoration(color: s ? AppTheme.primary : AppTheme.inputBg, borderRadius: BorderRadius.circular(10)),
              alignment: Alignment.center,
              child: Text(_labels[i], style: TextStyle(color: s ? Colors.white : AppTheme.textSecondary, fontSize: 13, fontWeight: FontWeight.w600)),
            )); },
        )))),
        Obx(() {
          if (controller.isLoading.value) return const SliverFillRemaining(child: Center(child: CircularProgressIndicator(color: AppTheme.primary)));
          if (controller.appointments.isEmpty) return const SliverFillRemaining(child: EmptyState(icon: Icons.calendar_today_outlined, title: 'لا توجد مواعيد'));
          return SliverPadding(padding: const EdgeInsets.all(20), sliver: SliverList(
            delegate: SliverChildBuilderDelegate((_, i) {
              final a = controller.appointments[i];
              return Container(
                margin: const EdgeInsets.only(bottom: 12), padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(color: AppTheme.white, borderRadius: BorderRadius.circular(16),
                    boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 12, offset: const Offset(0, 2))]),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                    Text(a.date, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                    StatusBadge(a.status),
                  ]),
                  const SizedBox(height: 6),
                  Text('${a.startTime.substring(0, 5)} – ${a.endTime.substring(0, 5)}', textDirection: TextDirection.ltr, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
                  Text('مريض: ${a.patientId.substring(0, 8)}...', style: const TextStyle(color: AppTheme.textHint, fontSize: 12)),
                  const SizedBox(height: 12),
                  Wrap(spacing: 8, runSpacing: 8, children: [
                    if (a.isPending) ...[
                      _chip('تأكيد', Icons.check_rounded, AppTheme.success, AppTheme.successSoft, () => controller.updateStatus(a.id, 'CONFIRMED')),
                      _chip('إلغاء', Icons.close_rounded, AppTheme.error, AppTheme.errorSoft, () => _notesDialog(context, a.id, 'CANCELLED', 'سبب الإلغاء')),
                    ],
                    if (a.isConfirmed) ...[
                      _chip('إتمام', Icons.check_double_outlined, AppTheme.success, AppTheme.successSoft, () => _notesDialog(context, a.id, 'COMPLETED', 'ملاحظات الكشف')),
                      _chip('لم يحضر', Icons.person_off_outlined, AppTheme.warning, AppTheme.warningSoft, () => controller.updateStatus(a.id, 'NO_SHOW')),
                      _chip('محادثة', Icons.chat_bubble_outline, AppTheme.primary, AppTheme.primaryLight, () => Get.toNamed('/doctor/chat', arguments: a.id)),
                      _chip('وصفة', Icons.medication_outlined, AppTheme.purple, AppTheme.purpleSoft, () => Get.toNamed('/doctor/add-prescription', arguments: a.id)),
                    ],
                    if (a.isCompleted) ...[
                      _chip('محادثة', Icons.chat_bubble_outline, AppTheme.primary, AppTheme.primaryLight, () => Get.toNamed('/doctor/chat', arguments: a.id)),
                      _chip('الوصفات', Icons.medication_outlined, AppTheme.purple, AppTheme.purpleSoft, () => Get.toNamed('/doctor/prescriptions', arguments: a.id)),
                    ],
                  ]),
                ]),
              );
            }, childCount: controller.appointments.length),
          ));
        }),
      ]),
    );
  }

  Widget _chip(String l, IconData i, Color c, Color bg, VoidCallback fn) => GestureDetector(onTap: fn, child: Container(
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
    decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(8)),
    child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(i, size: 14, color: c), const SizedBox(width: 5), Text(l, style: TextStyle(color: c, fontSize: 11.5, fontWeight: FontWeight.w600))]),
  ));

  void _notesDialog(BuildContext ctx, String id, String st, String hint) {
    final nc = TextEditingController();
    showModalBottomSheet(context: ctx, backgroundColor: AppTheme.white,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
        builder: (_) => Padding(padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(ctx).viewInsets.bottom + 20),
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(st == 'COMPLETED' ? 'إتمام الموعد' : 'إلغاء الموعد', style: const TextStyle(fontFamily: 'Cairo', fontSize: 18, fontWeight: FontWeight.w700)),
              const SizedBox(height: 14),
              TextField(controller: nc, maxLines: 3, decoration: InputDecoration(hintText: hint)),
              const SizedBox(height: 16),
              Row(children: [
                Expanded(child: OutlinedButton(onPressed: () => Get.back(), child: const Text('رجوع'))),
                const SizedBox(width: 10),
                Expanded(child: ElevatedButton(
                  onPressed: () { Get.back(); controller.updateStatus(id, st, notes: nc.text.trim().isNotEmpty ? nc.text.trim() : null); },
                  style: ElevatedButton.styleFrom(backgroundColor: st == 'COMPLETED' ? AppTheme.primary : AppTheme.error),
                  child: Text(st == 'COMPLETED' ? 'تأكيد' : 'إلغاء'),
                )),
              ]),
            ])));
  }
}

// ═══════════════════════════════════════════
// Schedule Screen
// ═══════════════════════════════════════════

class ScheduleScreen extends GetView<ScheduleController> {
  const ScheduleScreen({super.key});
  static const _days = ['MONDAY','TUESDAY','WEDNESDAY','THURSDAY','FRIDAY','SATURDAY','SUNDAY'];
  static const _dayAr = ['الإثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت','الأحد'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      floatingActionButton: FloatingActionButton(backgroundColor: AppTheme.primary, onPressed: () => _addDialog(context), child: const Icon(Icons.add_rounded, color: Colors.white)),
      body: Obx(() {
        if (controller.isLoading.value) return const Center(child: CircularProgressIndicator(color: AppTheme.primary));
        return RefreshIndicator(color: AppTheme.primary, onRefresh: controller.loadAll, child: CustomScrollView(slivers: [
          SliverToBoxAdapter(child: Container(color: AppTheme.white,
              padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top + 12, left: 20, right: 20, bottom: 16),
              child: const Text('جدول العمل', style: TextStyle(fontFamily: 'Cairo', fontSize: 22, fontWeight: FontWeight.w800)))),
          // Weekly
          SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
              child: const Text('الجدول الأسبوعي', style: TextStyle(fontFamily: 'Cairo', fontSize: 16, fontWeight: FontWeight.w700)))),
          if (controller.schedules.isEmpty)
            const SliverToBoxAdapter(child: Padding(padding: EdgeInsets.symmetric(horizontal: 20), child: EmptyState(icon: Icons.schedule_outlined, title: 'لا يوجد جدول', subtitle: 'اضغط + لتحديد مواعيد عملك')))
          else
            SliverPadding(padding: const EdgeInsets.symmetric(horizontal: 20), sliver: SliverList(
              delegate: SliverChildBuilderDelegate((_, i) {
                final s = controller.schedules[i];
                final di = _days.indexOf(s.dayOfWeek);
                return Container(
                  margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(color: AppTheme.white, borderRadius: BorderRadius.circular(14),
                      boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 10, offset: const Offset(0, 2))]),
                  child: Row(children: [
                    Container(width: 44, padding: const EdgeInsets.symmetric(vertical: 8),
                        decoration: BoxDecoration(color: s.isActive ? AppTheme.primaryLight : AppTheme.errorSoft, borderRadius: BorderRadius.circular(10)),
                        child: Center(child: Text(di >= 0 ? _dayAr[di].substring(0, 3) : '?', style: TextStyle(color: s.isActive ? AppTheme.primary : AppTheme.error, fontWeight: FontWeight.w700, fontSize: 12)))),
                    const SizedBox(width: 14),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(di >= 0 ? _dayAr[di] : s.dayOfWeek, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
                      const SizedBox(height: 3),
                      Text('${s.startTime.substring(0, 5)} – ${s.endTime.substring(0, 5)}  •  ${s.slotDuration} دقيقة', textDirection: TextDirection.ltr, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
                    ])),
                    IconButton(icon: const Icon(Icons.delete_outline_rounded, color: AppTheme.textHint, size: 20), onPressed: () => _confirmDel(context, s.id)),
                  ]),
                );
              }, childCount: controller.schedules.length),
            )),
          // Blocked
          SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.fromLTRB(20, 20, 20, 8), child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            const Text('أوقات محظورة', style: TextStyle(fontFamily: 'Cairo', fontSize: 16, fontWeight: FontWeight.w700)),
            TextButton.icon(onPressed: () => _addBlocked(context), icon: const Icon(Icons.add, size: 16), label: const Text('إضافة', style: TextStyle(fontSize: 12))),
          ]))),
          if (controller.blockedSlots.isEmpty)
            const SliverToBoxAdapter(child: Padding(padding: EdgeInsets.symmetric(horizontal: 20, vertical: 12), child: Center(child: Text('لا توجد أوقات محظورة', style: TextStyle(color: AppTheme.textSecondary, fontSize: 13)))))
          else
            SliverPadding(padding: const EdgeInsets.symmetric(horizontal: 20), sliver: SliverList(
              delegate: SliverChildBuilderDelegate((_, i) {
                final b = controller.blockedSlots[i];
                return Container(
                  margin: const EdgeInsets.only(bottom: 8), padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(color: AppTheme.errorSoft, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppTheme.error.withOpacity(0.15))),
                  child: Row(children: [
                    const Icon(Icons.block_rounded, color: AppTheme.error, size: 18),
                    const SizedBox(width: 12),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(b.date, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
                      if (b.startTime != null) Text('${b.startTime!.substring(0, 5)} – ${b.endTime?.substring(0, 5) ?? ''}', textDirection: TextDirection.ltr, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12))
                      else const Text('يوم كامل', style: TextStyle(color: AppTheme.error, fontSize: 12)),
                      if (b.reason != null) Text(b.reason!, style: const TextStyle(color: AppTheme.textHint, fontSize: 11)),
                    ])),
                    IconButton(icon: const Icon(Icons.close_rounded, color: AppTheme.error, size: 18), onPressed: () => controller.removeBlockedSlot(b.id)),
                  ]),
                );
              }, childCount: controller.blockedSlots.length),
            )),
          const SliverToBoxAdapter(child: SizedBox(height: 80)),
        ]));
      }),
    );
  }

  void _addDialog(BuildContext ctx) {
    String day = 'MONDAY'; final sc = TextEditingController(text: '09:00'); final ec = TextEditingController(text: '17:00'); final dc = TextEditingController(text: '30');
    showModalBottomSheet(context: ctx, isScrollControlled: true, backgroundColor: AppTheme.white,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
        builder: (_) => Padding(padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(ctx).viewInsets.bottom + 20),
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('إضافة جدول', style: TextStyle(fontFamily: 'Cairo', fontSize: 18, fontWeight: FontWeight.w700)),
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(value: day, decoration: const InputDecoration(labelText: 'اليوم'), dropdownColor: AppTheme.white,
                  items: List.generate(7, (i) => DropdownMenuItem(value: _days[i], child: Text(_dayAr[i]))), onChanged: (v) => day = v!),
              const SizedBox(height: 10),
              Row(children: [
                Expanded(child: TextField(controller: sc, decoration: const InputDecoration(labelText: 'من (HH:MM)'), textDirection: TextDirection.ltr)),
                const SizedBox(width: 10),
                Expanded(child: TextField(controller: ec, decoration: const InputDecoration(labelText: 'إلى (HH:MM)'), textDirection: TextDirection.ltr)),
              ]),
              const SizedBox(height: 10),
              TextField(controller: dc, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'مدة الموعد (دقائق)'), textDirection: TextDirection.ltr),
              const SizedBox(height: 16),
              ElevatedButton(onPressed: () { Get.back(); controller.createSchedule(dayOfWeek: day, startTime: sc.text.trim(), endTime: ec.text.trim(), slotDuration: int.tryParse(dc.text.trim()) ?? 30); }, child: const Text('إضافة')),
            ])));
  }

  void _addBlocked(BuildContext ctx) {
    DateTime? pd; final rc = TextEditingController();
    showModalBottomSheet(context: ctx, backgroundColor: AppTheme.white,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
        builder: (_) => StatefulBuilder(builder: (ctx2, setState2) => Padding(
            padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(ctx).viewInsets.bottom + 20),
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('حظر يوم', style: TextStyle(fontFamily: 'Cairo', fontSize: 18, fontWeight: FontWeight.w700)),
              const SizedBox(height: 14),
              GestureDetector(
                onTap: () async { final d = await showDatePicker(context: ctx2, firstDate: DateTime.now(), lastDate: DateTime.now().add(const Duration(days: 365))); if (d != null) setState2(() => pd = d); },
                child: Container(width: double.infinity, padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: AppTheme.inputBg, borderRadius: BorderRadius.circular(12)),
                    child: Text(pd != null ? '${pd!.year}-${pd!.month.toString().padLeft(2,'0')}-${pd!.day.toString().padLeft(2,'0')}' : 'اختر التاريخ', style: TextStyle(color: pd != null ? AppTheme.textPrimary : AppTheme.textHint))),
              ),
              const SizedBox(height: 10),
              TextField(controller: rc, decoration: const InputDecoration(hintText: 'السبب (اختياري)')),
              const SizedBox(height: 16),
              ElevatedButton(
                onPressed: pd == null ? null : () { Get.back();
                  controller.addBlockedSlot(date: '${pd!.year}-${pd!.month.toString().padLeft(2,'0')}-${pd!.day.toString().padLeft(2,'0')}', reason: rc.text.trim().isNotEmpty ? rc.text.trim() : null); },
                style: ElevatedButton.styleFrom(backgroundColor: AppTheme.error),
                child: const Text('حظر اليوم'),
              ),
            ]))));
  }

  void _confirmDel(BuildContext ctx, String id) {
    showDialog(context: ctx, builder: (_) => AlertDialog(backgroundColor: AppTheme.white, title: const Text('حذف الجدول؟'),
        actions: [TextButton(onPressed: () => Get.back(), child: const Text('إلغاء')),
          TextButton(onPressed: () { Get.back(); controller.deleteSchedule(id); }, child: const Text('حذف', style: TextStyle(color: AppTheme.error)))]));
  }
}

// ═══════════════════════════════════════════
// Doctor Profile
// ═══════════════════════════════════════════

class DoctorProfileScreen extends StatelessWidget {
  const DoctorProfileScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final storage = Get.find<StorageProvider>();
    return Scaffold(
      backgroundColor: AppTheme.bg,
      body: FutureBuilder<String?>(future: storage.getUserName(), builder: (_, snap) {
        final name = snap.data ?? 'دكتور';
        return CustomScrollView(slivers: [
          SliverToBoxAdapter(child: Container(color: AppTheme.white,
              padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top + 12, bottom: 24),
              child: Column(children: [
                Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  const Text('حسابي', style: TextStyle(fontFamily: 'Cairo', fontSize: 22, fontWeight: FontWeight.w800)),
                  GestureDetector(onTap: () => _logout(context), child: Container(width: 38, height: 38, decoration: BoxDecoration(color: AppTheme.errorSoft, borderRadius: BorderRadius.circular(10)),
                      child: const Icon(Icons.logout_rounded, color: AppTheme.error, size: 18))),
                ])),
                const SizedBox(height: 20),
                UserAvatar(name: name, size: 68),
                const SizedBox(height: 12),
                Text(name, style: const TextStyle(fontFamily: 'Cairo', fontSize: 19, fontWeight: FontWeight.w700)),
                const SizedBox(height: 2),
                const Text('طبيب', style: TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
              ]))),
          SliverPadding(padding: const EdgeInsets.all(20), sliver: SliverList(delegate: SliverChildListDelegate([
            _menu(Icons.campaign_outlined, 'الإعلانات', () => Get.toNamed('/doctor/announcements')),
            _menu(Icons.notifications_outlined, 'الإشعارات', () => Get.toNamed('/doctor/notifications')),
          ]))),
        ]);
      }),
    );
  }

  Widget _menu(IconData i, String l, VoidCallback fn) => GestureDetector(onTap: fn, child: Container(
    margin: const EdgeInsets.only(bottom: 8), padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
    decoration: BoxDecoration(color: AppTheme.white, borderRadius: BorderRadius.circular(14),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.02), blurRadius: 8, offset: const Offset(0, 2))]),
    child: Row(children: [Icon(i, color: AppTheme.textSecondary, size: 20), const SizedBox(width: 12),
      Expanded(child: Text(l, style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 14))),
      const Icon(Icons.arrow_back_ios_rounded, color: AppTheme.textHint, size: 14)]),
  ));

  void _logout(BuildContext ctx) {
    showModalBottomSheet(context: ctx, backgroundColor: AppTheme.white,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
        builder: (_) => Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 56, height: 56, decoration: BoxDecoration(color: AppTheme.errorSoft, borderRadius: BorderRadius.circular(16)),
              child: const Icon(Icons.logout_rounded, color: AppTheme.error, size: 28)),
          const SizedBox(height: 16),
          const Text('تسجيل الخروج', style: TextStyle(fontFamily: 'Cairo', fontSize: 18, fontWeight: FontWeight.w700)),
          const SizedBox(height: 6),
          const Text('هل تريد تسجيل الخروج؟', style: TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
          const SizedBox(height: 20),
          Row(children: [
            Expanded(child: OutlinedButton(onPressed: () => Get.back(), child: const Text('إلغاء'))),
            const SizedBox(width: 10),
            Expanded(child: ElevatedButton(onPressed: () { Get.back(); Get.find<AuthController>().logout(); },
                style: ElevatedButton.styleFrom(backgroundColor: AppTheme.error), child: const Text('خروج'))),
          ]),
        ])));
  }
}

// ═══════════════════════════════════════════
// Doctor Chat
// ═══════════════════════════════════════════

class DoctorChatScreen extends StatefulWidget {
  const DoctorChatScreen({super.key});
  @override
  State<DoctorChatScreen> createState() => _DChatState();
}

class _DChatState extends State<DoctorChatScreen> {
  late final DoctorChatController ctrl;
  final _sc = ScrollController();

  @override
  void initState() { super.initState(); ctrl = Get.put(DoctorChatController()); ctrl.setAppointmentId(Get.arguments as String); }
  void _scroll() { WidgetsBinding.instance.addPostFrameCallback((_) { if (_sc.hasClients) _sc.animateTo(_sc.position.maxScrollExtent, duration: const Duration(milliseconds: 200), curve: Curves.easeOut); }); }
  @override
  void dispose() { _sc.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      appBar: AppBar(backgroundColor: AppTheme.white, title: const Text('محادثة مع المريض'),
          leading: IconButton(icon: const Icon(Icons.arrow_forward_rounded), onPressed: () => Get.back()),
          actions: [IconButton(icon: const Icon(Icons.refresh_rounded), onPressed: ctrl.loadMessages)]),
      body: Column(children: [
        Expanded(child: Obx(() {
          if (ctrl.isLoading.value && ctrl.messages.isEmpty) return const Center(child: CircularProgressIndicator(color: AppTheme.primary));
          if (ctrl.messages.isEmpty) return const EmptyState(icon: Icons.chat_bubble_outline_rounded, title: 'لا توجد رسائل', subtitle: 'ابدأ محادثة مع المريض');
          _scroll();
          return ListView.builder(controller: _sc, padding: const EdgeInsets.all(16), itemCount: ctrl.messages.length, itemBuilder: (_, i) {
            final m = ctrl.messages[i]; final me = m.senderRole == 'DOCTOR';
            return Align(alignment: me ? Alignment.centerLeft : Alignment.centerRight, child: Container(
              constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
              margin: const EdgeInsets.only(bottom: 8), padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(color: me ? AppTheme.primary : AppTheme.white,
                  borderRadius: BorderRadius.only(topLeft: const Radius.circular(14), topRight: const Radius.circular(14),
                      bottomLeft: Radius.circular(me ? 4 : 14), bottomRight: Radius.circular(me ? 14 : 4)),
                  boxShadow: me ? null : [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8, offset: const Offset(0, 2))]),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                if (!me) const Padding(padding: EdgeInsets.only(bottom: 4), child: Text('المريض', style: TextStyle(color: AppTheme.primary, fontSize: 11, fontWeight: FontWeight.w700))),
                Text(m.message, style: TextStyle(color: me ? Colors.white : AppTheme.textPrimary, fontSize: 14, height: 1.4)),
                const SizedBox(height: 4),
                Text(_ft(m.createdAt), style: TextStyle(color: me ? Colors.white60 : AppTheme.textHint, fontSize: 10)),
              ]),
            ));
          });
        })),
        Container(
          padding: const EdgeInsets.fromLTRB(16, 10, 8, 10),
          decoration: BoxDecoration(color: AppTheme.white, boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8, offset: const Offset(0, -2))]),
          child: SafeArea(top: false, child: Row(children: [
            Expanded(child: TextField(controller: ctrl.messageCtrl,
                decoration: InputDecoration(hintText: 'اكتب رسالة...', filled: true, fillColor: AppTheme.inputBg,
                    contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none)),
                textInputAction: TextInputAction.send, onSubmitted: (_) => ctrl.sendMessage())),
            const SizedBox(width: 6),
            Obx(() => GestureDetector(onTap: ctrl.isSending.value ? null : ctrl.sendMessage,
                child: Container(width: 42, height: 42, decoration: BoxDecoration(color: AppTheme.primary, borderRadius: BorderRadius.circular(12)),
                    child: ctrl.isSending.value
                        ? const Padding(padding: EdgeInsets.all(10), child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                        : const Icon(Icons.send_rounded, color: Colors.white, size: 20)))),
          ])),
        ),
      ]),
    );
  }
  String _ft(String dt) { try { final d = DateTime.parse(dt); return '${d.hour.toString().padLeft(2,'0')}:${d.minute.toString().padLeft(2,'0')}'; } catch (_) { return ''; } }
}

// ═══════════════════════════════════════════
// Add Prescription
// ═══════════════════════════════════════════

class AddPrescriptionScreen extends StatefulWidget {
  const AddPrescriptionScreen({super.key});
  @override
  State<AddPrescriptionScreen> createState() => _AddRxState();
}

class _AddRxState extends State<AddPrescriptionScreen> {
  late final AddPrescriptionController ctrl;
  late final String apptId;

  @override
  void initState() { super.initState(); ctrl = Get.put(AddPrescriptionController()); apptId = Get.arguments as String; }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      appBar: AppBar(backgroundColor: AppTheme.white, title: const Text('إضافة وصفة'),
          leading: IconButton(icon: const Icon(Icons.arrow_forward_rounded), onPressed: () => Get.back())),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: AppTheme.white, borderRadius: BorderRadius.circular(16),
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 12, offset: const Offset(0, 2))]),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Row(children: [Icon(Icons.medication_rounded, color: AppTheme.primary, size: 20), SizedBox(width: 8),
                Text('تفاصيل الوصفة', style: TextStyle(fontFamily: 'Cairo', fontWeight: FontWeight.w700, fontSize: 15))]),
              const SizedBox(height: 18),
              _f('اسم الدواء *', ctrl.medicationCtrl, 'مثال: أموكسيسيلين'),
              _f('الجرعة', ctrl.dosageCtrl, 'مثال: 500mg'),
              _f('التكرار', ctrl.frequencyCtrl, 'مثال: مرتين يومياً'),
              _f('المدة', ctrl.durationCtrl, 'مثال: 7 أيام'),
              _f('ملاحظات', ctrl.notesCtrl, 'تعليمات إضافية...', ml: 3),
            ])),
        const SizedBox(height: 24),
        Obx(() => ElevatedButton.icon(
          onPressed: ctrl.isSaving.value ? null : () async {
            final ok = await ctrl.save(apptId);
            if (ok) { ctrl.clear(); Get.back();
              Get.snackbar('تمت الإضافة', 'تم حفظ الوصفة', snackPosition: SnackPosition.BOTTOM, backgroundColor: AppTheme.successSoft, colorText: AppTheme.success); }
          },
          icon: ctrl.isSaving.value ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.save_rounded, size: 18),
          label: const Text('حفظ الوصفة'),
        )),
      ]),
    );
  }

  Widget _f(String l, TextEditingController c, String h, {int ml = 1}) => Padding(padding: const EdgeInsets.only(bottom: 14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text(l, style: const TextStyle(color: AppTheme.textSecondary, fontSize: 12.5, fontWeight: FontWeight.w500)),
    const SizedBox(height: 6),
    TextField(controller: c, maxLines: ml, decoration: InputDecoration(hintText: h)),
  ]));
}
