import 'package:flutter/material.dart';

class AppTheme {
  // ── Brand Colors ──
  static const Color primary = Color(0xFF2A9D8F);       // Teal from the design
  static const Color primaryDark = Color(0xFF1F7A6E);
  static const Color primaryLight = Color(0xFFE8F5F2);  // Very soft teal bg
  static const Color primarySoft = Color(0x182A9D8F);

  // ── Backgrounds ──
  static const Color bg = Color(0xFFF7F8FA);             // Light gray bg
  static const Color white = Color(0xFFFFFFFF);
  static const Color card = Color(0xFFFFFFFF);
  static const Color inputBg = Color(0xFFF2F4F7);

  // ── Text ──
  static const Color textPrimary = Color(0xFF1A1D26);
  static const Color textSecondary = Color(0xFF6B7280);
  static const Color textHint = Color(0xFF9CA3AF);
  static const Color textWhite = Color(0xFFFFFFFF);

  // ── Accents ──
  static const Color success = Color(0xFF22C55E);
  static const Color successSoft = Color(0x1822C55E);
  static const Color error = Color(0xFFEF4444);
  static const Color errorSoft = Color(0x18EF4444);
  static const Color warning = Color(0xFFF59E0B);
  static const Color warningSoft = Color(0x18F59E0B);
  static const Color info = Color(0xFF3B82F6);
  static const Color infoSoft = Color(0x183B82F6);

  // ── Borders & Shadows ──
  static const Color border = Color(0xFFE5E7EB);
  static const Color borderLight = Color(0xFFF0F1F3);
  static const Color shadow = Color(0x0A000000);

  // ── Gradient ──
  static const LinearGradient brandGradient = LinearGradient(
    colors: [primary, Color(0xFF3DB8A9)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  // ═══════════════════════════════════════════
  // Backward-compatible aliases
  // (so existing screens compile without edits)
  // ═══════════════════════════════════════════

  static const Color blue = primary;
  static const Color blueSoft = primarySoft;
  static const Color teal = Color(0xFF22C55E);       // maps to success green
  static const Color tealSoft = successSoft;
  static const Color red = error;
  static const Color redSoft = errorSoft;
  static const Color amber = warning;
  static const Color amberSoft = warningSoft;
  static const Color purple = Color(0xFF8B5CF6);
  static const Color purpleSoft = Color(0x188B5CF6);
  static const Color bgCard = card;
  static const Color bgInput = inputBg;
  static const Color textDim = textSecondary;
  static const Color textFaint = textHint;

  // ── Card Decoration ──
  static BoxDecoration get cardDecoration => BoxDecoration(
        color: card,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: shadow,
            blurRadius: 20,
            offset: const Offset(0, 4),
          ),
        ],
      );

  static BoxDecoration get cardDecorationBordered => BoxDecoration(
        color: card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: border, width: 1),
      );

  // ═══════════════════════════════════════════
  // Theme Data
  // ═══════════════════════════════════════════

  static ThemeData get lightTheme => ThemeData(
        brightness: Brightness.light,
        scaffoldBackgroundColor: bg,
        primaryColor: primary,
        colorScheme: const ColorScheme.light(
          primary: primary,
          secondary: primaryDark,
          surface: card,
          error: error,
          onPrimary: textWhite,
        ),
        fontFamily: 'Cairo',
        appBarTheme: const AppBarTheme(
          backgroundColor: white,
          elevation: 0,
          centerTitle: true,
          scrolledUnderElevation: 0.5,
          surfaceTintColor: Colors.transparent,
          titleTextStyle: TextStyle(
            fontFamily: 'Cairo',
            fontSize: 18,
            fontWeight: FontWeight.w700,
            color: textPrimary,
          ),
          iconTheme: IconThemeData(color: textPrimary),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: inputBg,
          hintStyle: const TextStyle(
            color: textHint,
            fontSize: 14,
            fontFamily: 'Cairo',
            fontWeight: FontWeight.w400,
          ),
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none,
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: primary, width: 1.5),
          ),
          errorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: error, width: 1),
          ),
          focusedErrorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: error, width: 1.5),
          ),
          errorStyle: const TextStyle(
            color: error,
            fontSize: 12,
            fontFamily: 'Cairo',
          ),
          prefixIconColor: textHint,
          suffixIconColor: textHint,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: primary,
            foregroundColor: textWhite,
            elevation: 0,
            minimumSize: const Size(double.infinity, 54),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14),
            ),
            textStyle: const TextStyle(
              fontFamily: 'Cairo',
              fontSize: 16,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
        outlinedButtonTheme: OutlinedButtonThemeData(
          style: OutlinedButton.styleFrom(
            foregroundColor: primary,
            side: const BorderSide(color: border, width: 1.5),
            minimumSize: const Size(double.infinity, 54),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14),
            ),
            textStyle: const TextStyle(
              fontFamily: 'Cairo',
              fontSize: 16,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        textButtonTheme: TextButtonThemeData(
          style: TextButton.styleFrom(
            foregroundColor: primary,
            textStyle: const TextStyle(
              fontFamily: 'Cairo',
              fontSize: 14,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        snackBarTheme: SnackBarThemeData(
          backgroundColor: textPrimary,
          contentTextStyle: const TextStyle(
            color: textWhite,
            fontFamily: 'Cairo',
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          behavior: SnackBarBehavior.floating,
        ),
        bottomNavigationBarTheme: const BottomNavigationBarThemeData(
          backgroundColor: white,
          selectedItemColor: primary,
          unselectedItemColor: textHint,
          type: BottomNavigationBarType.fixed,
          elevation: 0,
          selectedLabelStyle: TextStyle(
            fontFamily: 'Cairo',
            fontSize: 12,
            fontWeight: FontWeight.w600,
          ),
          unselectedLabelStyle: TextStyle(
            fontFamily: 'Cairo',
            fontSize: 12,
          ),
        ),
        dividerTheme: const DividerThemeData(
          color: borderLight,
          thickness: 1,
        ),
        chipTheme: ChipThemeData(
          backgroundColor: inputBg,
          selectedColor: primaryLight,
          labelStyle: const TextStyle(
            fontFamily: 'Cairo',
            fontSize: 13,
            fontWeight: FontWeight.w500,
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
          side: const BorderSide(color: Colors.transparent),
        ),
      );
}
