import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../app/config/app_constants.dart';
import '../../../app/config/app_theme.dart';
import '../../../core/errors/api_exceptions.dart';
import '../../../data/repositories/auth_repository.dart';

class AuthController extends GetxController {
  final AuthRepository _repo = AuthRepository();

  // ── Observable state ──
  final isLoading = false.obs;
  final obscurePassword = true.obs;
  final obscureConfirm = true.obs;

  // ── Clinic ID ──
  final clinicId = ''.obs;

  // ── Form keys ──
  final clinicIdFormKey = GlobalKey<FormState>();
  final loginFormKey = GlobalKey<FormState>();
  final registerFormKey = GlobalKey<FormState>();

  // ── Text controllers ──
  final clinicIdCtrl = TextEditingController();
  final identifierCtrl = TextEditingController();
  final passwordCtrl = TextEditingController();
  final nameCtrl = TextEditingController();
  final emailCtrl = TextEditingController();
  final phoneCtrl = TextEditingController();
  final regPasswordCtrl = TextEditingController();
  final confirmPasswordCtrl = TextEditingController();

  @override
  void onClose() {
    clinicIdCtrl.dispose();
    identifierCtrl.dispose();
    passwordCtrl.dispose();
    nameCtrl.dispose();
    emailCtrl.dispose();
    phoneCtrl.dispose();
    regPasswordCtrl.dispose();
    confirmPasswordCtrl.dispose();
    super.onClose();
  }

  // ═══════════════════════════════════════════
  // Splash
  // ═══════════════════════════════════════════

  Future<void> checkSession() async {
    await Future.delayed(const Duration(milliseconds: 1800));
    final hasSession = await _repo.hasSession();
    if (!hasSession) {
      Get.offAllNamed('/clinic-id');
      return;
    }
    final role = await _repo.getSavedRole();
    _navigateByRole(role);
  }

  // ═══════════════════════════════════════════
  // Clinic ID
  // ═══════════════════════════════════════════

  void submitClinicId() {
    if (!clinicIdFormKey.currentState!.validate()) return;
    clinicId.value = clinicIdCtrl.text.trim().toUpperCase();
    Get.toNamed('/login');
  }

  // ═══════════════════════════════════════════
  // Login
  // ═══════════════════════════════════════════

  Future<void> login() async {
    if (!loginFormKey.currentState!.validate()) return;

    isLoading.value = true;
    try {
      final result = await _repo.clinicLogin(
        clinicId: clinicId.value,
        identifier: identifierCtrl.text.trim(),
        password: passwordCtrl.text,
      );
      final role = result['role'] as String?;
      _showSuccess('تم تسجيل الدخول بنجاح');
      _navigateByRole(role);
    } on ApiException catch (e) {
      _showError(e.message);
    } catch (e) {
      _showError('حدث خطأ. حاول مرة أخرى.');
    } finally {
      isLoading.value = false;
    }
  }

  // ═══════════════════════════════════════════
  // Register
  // ═══════════════════════════════════════════

  Future<void> registerPatient() async {
    if (!registerFormKey.currentState!.validate()) return;

    if (emailCtrl.text.trim().isEmpty && phoneCtrl.text.trim().isEmpty) {
      _showError('يجب إدخال البريد الإلكتروني أو رقم الهاتف');
      return;
    }

    isLoading.value = true;
    try {
      await _repo.registerPatient(
        clinicId: clinicId.value,
        name: nameCtrl.text.trim(),
        email: emailCtrl.text.trim().isNotEmpty ? emailCtrl.text.trim() : null,
        phoneNumber:
            phoneCtrl.text.trim().isNotEmpty ? phoneCtrl.text.trim() : null,
        password: regPasswordCtrl.text,
      );
      _showSuccess('تم التسجيل بنجاح! يرجى انتظار موافقة العيادة.');
      _clearRegisterFields();
      Get.offNamed('/login');
    } on ApiException catch (e) {
      _showError(e.message);
    } catch (e) {
      _showError('فشل التسجيل. حاول مرة أخرى.');
    } finally {
      isLoading.value = false;
    }
  }

  // ═══════════════════════════════════════════
  // Logout
  // ═══════════════════════════════════════════

  Future<void> logout() async {
    await _repo.logout();
    _clearAllFields();
    Get.offAllNamed('/clinic-id');
  }

  // ═══════════════════════════════════════════
  // Helpers
  // ═══════════════════════════════════════════

  void _navigateByRole(String? role) {
    switch (role) {
      case AppConstants.roleDoctor:
        Get.offAllNamed('/doctor');
        break;
      case AppConstants.rolePatient:
        Get.offAllNamed('/patient');
        break;
      default:
        Get.offAllNamed('/clinic-id');
    }
  }

  void _clearRegisterFields() {
    nameCtrl.clear();
    emailCtrl.clear();
    phoneCtrl.clear();
    regPasswordCtrl.clear();
    confirmPasswordCtrl.clear();
  }

  void _clearAllFields() {
    clinicIdCtrl.clear();
    identifierCtrl.clear();
    passwordCtrl.clear();
    clinicId.value = '';
    _clearRegisterFields();
  }

  void _showError(String message) {
    Get.snackbar(
      'خطأ',
      message,
      snackPosition: SnackPosition.BOTTOM,
      backgroundColor: AppTheme.errorSoft,
      colorText: AppTheme.error,
      icon: const Icon(Icons.error_outline_rounded, color: AppTheme.error),
      margin: const EdgeInsets.all(16),
      duration: const Duration(seconds: 3),
      borderRadius: 12,
    );
  }

  void _showSuccess(String message) {
    Get.snackbar(
      'نجاح',
      message,
      snackPosition: SnackPosition.BOTTOM,
      backgroundColor: AppTheme.successSoft,
      colorText: AppTheme.success,
      icon:
          const Icon(Icons.check_circle_outline_rounded, color: AppTheme.success),
      margin: const EdgeInsets.all(16),
      duration: const Duration(seconds: 3),
      borderRadius: 12,
    );
  }
}
